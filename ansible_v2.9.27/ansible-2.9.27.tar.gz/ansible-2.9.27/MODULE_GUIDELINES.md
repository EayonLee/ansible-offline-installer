# Module Maintainer Guidelines

The Ansible Module Maintainer Guidelines can now be found in the [official Ansible community guide](https://docs.ansible.com/ansible/latest/community/maintainers.html).

See also the [Developers Guide](https://docs.ansible.com/ansible/latest/dev_guide/)
